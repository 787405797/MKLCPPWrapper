#ifndef __LFM_RADAR_H
#define __LFM_RADAR_H

void LFM_radar(double T, double B, double Rmin, double Rmax, double* R, double* RCS, int N);
void LFM_radar();

#endif
